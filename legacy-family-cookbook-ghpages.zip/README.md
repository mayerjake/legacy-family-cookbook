# Legacy Family Cookbook

A static, Sitely-ready website to preserve family recipes and stories.

## Quick Start
- Import into Sitely Pro via **File → Import Website…**
- Start at `index.html`

## Structure
- `index.html` — landing page with featured recipes
- `recipes.html` — searchable list
- `story.html` — family narrative page
- `submit.html` — form preview (no backend)

## Customize
- Replace images in `assets/images/`
- Add/edit recipes in `data/sample_recipes.json`
- Tweak styles in `assets/css/styles.css`

