# Legacy Family Cookbook — GitHub Pages

This folder is ready to publish on **GitHub Pages** and import into **Sitely** from a live URL.

## Quick Publish (new repo)

1. Create a new repo on GitHub named `legacy-family-cookbook` (public or private with Pages enabled).
2. On your Mac:
   ```bash
   cd ~/Downloads
   unzip legacy-family-cookbook-ghpages.zip
   cd legacy-family-cookbook-ghpages
   git init -b main
   git add .
   git commit -m "Initial commit — Legacy Family Cookbook"
   git remote add origin https://github.com/<YOUR-ACCOUNT>/legacy-family-cookbook.git
   git push -u origin main
   ```
3. In the repo on GitHub:
   - Go to **Settings → Pages** and set **Source** to **GitHub Actions** (will auto-detect this workflow).
   - Wait for the **Actions** tab to finish the deploy. You’ll get a URL like:
     `https://<YOUR-ACCOUNT>.github.io/legacy-family-cookbook/`

4. Confirm the site loads at that URL.

## Import into Sitely (URL-only import)

- Open Sitely and choose **Import from URL**.
- Paste your Pages URL (e.g., `https://<YOUR-ACCOUNT>.github.io/legacy-family-cookbook/`).
- Sitely will crawl and import the site.

## Notes

- `.nojekyll` prevents Jekyll from altering file paths.
- If you want a **custom domain**, add a `CNAME` file at the repo root with your domain (e.g., `cookbook.example.com`) and point DNS to GitHub Pages.
- To update the site, just **commit and push**; the workflow redeploys automatically.
