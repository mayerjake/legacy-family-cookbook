
async function fetchJSON(path){ const res = await fetch(path); return res.json(); }
function el(tag, attrs={}, ...children){
  const node = Object.assign(document.createElement(tag), attrs);
  for(const c of children){ if(typeof c === 'string') node.appendChild(document.createTextNode(c)); else if(c) node.appendChild(c); }
  return node;
}
function recipeCard(r){
  const img = el('img', {src: r.image || 'assets/images/placeholder-card.png', alt: r.name});
  const pic = el('div', {className:'pic'}, img);
  const badge = el('div', {className:'badge'}, r.branch || 'Heirloom');
  const meta = el('div', {className:'meta'}, el('h3', {}, r.name), el('p', {}, r.description || ''));
  const card = el('article', {className:'card'} , el('div', {style:'position:relative'}, badge, pic), meta);
  return card;
}

(async ()=>{
  const onIndex = document.getElementById('featured-cards');
  const onList = document.getElementById('recipe-list');
  const data = await fetchJSON('data/sample_recipes.json').catch(()=>({recipes:[]}));

  if(onIndex && data.recipes){
    for(const r of data.recipes.slice(0,6)){ onIndex.appendChild(recipeCard(r)); }
  }
  if(onList && data.recipes){
    let list = data.recipes.slice();
    const search = document.getElementById('search');
    function render(items){
      onList.innerHTML = '';
      for(const r of items){ onList.appendChild(recipeCard(r)); }
    }
    render(list);
    if(search){
      search.addEventListener('input', e => {
        const q = e.target.value.toLowerCase();
        render(list.filter(r => (r.name + ' ' + (r.ingredients||'') + ' ' + (r.branch||'')).toLowerCase().includes(q)));
      });
    }
  }

  const form = document.getElementById('recipe-form');
  if(form){
    form.addEventListener('submit', (e)=>{
      e.preventDefault();
      const data = Object.fromEntries(new FormData(form).entries());
      const prev = document.getElementById('preview');
      prev.innerHTML = '';
      const pre = document.createElement('pre');
      pre.textContent = JSON.stringify(data, null, 2);
      prev.appendChild(pre);
      window.scrollTo({top: prev.offsetTop - 20, behavior:'smooth'});
    });
  }
})();
