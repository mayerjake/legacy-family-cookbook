# Importing to Sitely Pro 4.x (macOS)
1) Open Sitely Pro.
2) Go to **File ▸ Import Website…**.
3) Select the folder `legacy-family-cookbook` or the ZIP you downloaded.
4) Ensure **Include assets** is checked.
5) Finish import. If prompted about paths, choose **Preserve folder structure**.
6) Set `index.html` as the start page if needed.
7) Publish/Preview within Sitely.
