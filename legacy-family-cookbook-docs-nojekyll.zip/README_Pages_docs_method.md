# Legacy Family Cookbook — GitHub Pages (docs/ method)

This package uses the **docs/** folder method so you can publish without GitHub Actions.

## Steps
1. Create a repo on GitHub (e.g., `legacy-family-cookbook`).
2. Upload the **contents of this ZIP** to the repo root (keep the `docs/` folder intact).
   - Easiest: drag-and-drop the *files* in GitHub's web UI.
3. In the repo: go to **Settings → Pages**.
4. Under **Build and deployment → Source**, choose **Deploy from a branch**.
5. Set **Branch:** `main` and **Folder:** `/docs` → **Save**.
6. Wait for the build (a green check appears). Your site will be at:
   `https://<YOUR-ACCOUNT>.github.io/legacy-family-cookbook/`

## Notes
- All files live under `docs/` so GitHub Pages serves them directly.
- If you later want a custom domain, add `docs/CNAME` containing the domain name and point DNS to GitHub Pages.
