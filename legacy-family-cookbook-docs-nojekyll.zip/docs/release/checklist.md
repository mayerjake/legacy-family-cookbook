# Preflight Checklist

- [ ] Favicon visible in browser tab
- [ ] Links: Recipes / Story / Submit working
- [ ] Images optimized (PNG under 500KB where possible)
- [ ] Mobile view: header, buttons, and cards render correctly
- [ ] Search filters recipes as you type
- [ ] site.webmanifest loads without errors
- [ ] Replace sample emails with your real address
- [ ] Add real scans/photos to `assets/images/`
