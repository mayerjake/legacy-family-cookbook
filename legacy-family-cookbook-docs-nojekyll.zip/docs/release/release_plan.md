# Release Plan — Legacy Family Cookbook

## Phase 1 — Internal Beta (Week 1)
- Import site to Sitely and validate layout on desktop + mobile.
- Upload 15–25 seed recipes (use `data/sample_recipes.json` as template).
- Collect 3–5 scans of handwritten cards and add to `assets/images/`.
- Share private preview link with 6–10 family members for feedback.

## Phase 2 — Public Launch (Week 2)
- Finalize logo & colors (brand kit included).
- Add “Submit a Recipe” instructions and an email link.
- Prepare a short launch post + 5 images.
- Turn on indexing (optional) and share on family group threads.

## Phase 3 — Ongoing (Weeks 3+)
- Monthly curation: rotate featured recipes on home page.
- Quarterly story drives: prompt relatives to share memories.
- Backups: export ZIP from Sitely monthly.

## Success Metrics
- # of recipes added per month.
- % of relatives who contribute at least once.
- Duplicates resolved and stories attached to recipes.

