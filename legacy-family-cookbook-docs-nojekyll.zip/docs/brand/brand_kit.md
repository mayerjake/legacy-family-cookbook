# Legacy Family Cookbook · Brand Kit

**Positioning**: Heirloom, warm, trustworthy; a living archive for family recipes and stories.

## Logo
- Primary seal mark: `assets/images/logo.svg`
- Clear space: 1× the logo circle radius on all sides.
- Minimum size: 24px height for digital.

## Colors
- Primary (Herb): `#3B5D3E`
- Accent (Brass): `#B6864A`
- Ink (Body Text): `#1E1E1E`
- Muted: `#6B7280`
- Paper Background: `#FFFDF8`
- Link: `#2E6D8F`

## Typography (System stack)
- Headings: Georgia, Times, serif (classic book feel)
- Body: System Sans (Inter/Segoe UI/Roboto/Arial)

## Imagery
- Scanned cards, table scenes, cookware close-ups.
- Use natural light, matte finish.

## Voice & Tone
- Gentle, familial, specific details (“Grandma Rosa’s cast-iron pan”).

## Buttons
- Primary: Solid Herb background, white text.
- Secondary: White with subtle paper border.

